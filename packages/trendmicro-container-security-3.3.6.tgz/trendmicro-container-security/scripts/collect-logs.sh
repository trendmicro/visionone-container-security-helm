#!/bin/bash
#
# a helper script to fetch Kubernetes settings and Trend Micro Vision One container security logs.
#

RELEASE=${RELEASE:-trendmicro}
KUBECTL=kubectl
HELM=helm

#####
# check prerequisites
#####
command_exists () {
  command -v "$1" >/dev/null 2>&1
}

# Check if kubectl exists, if not,try to use oc
if ! command_exists $KUBECTL; then
  echo "No kubectl command found, switching to oc..."
  KUBECTL=oc #For Openshift environments
  if ! command_exists $KUBECTL; then
    echo "Neither kubectl nor oc command found, exiting..."
    exit 1
  fi
fi

if ! command_exists $HELM; then
  echo "No helm command found, exiting..."
  exit 1
fi

CURRENT_NS=$($KUBECTL config view --minify --output 'jsonpath={..namespace}')
CURRENT_NS=${CURRENT_NS:-trendmicro-system}
NAMESPACE=${NAMESPACE:-$CURRENT_NS}
NAMESPACE_PARAM="--namespace=$NAMESPACE"

PODS=$($KUBECTL get pods "$NAMESPACE_PARAM" -o=jsonpath='{range .items[*]}{.metadata.name}{";"}{end}' -l app.kubernetes.io/instance=$RELEASE)
if [ -z "${PODS}" ]; then
  echo "No container security pods are found in release '$RELEASE' in namespace '$NAMESPACE'.  You can use RELEASE and NAMESPACE environment variable to change its default settings."
  exit 1
fi

# Get Helm version since 'helm list' on Helm 3+ does not display all namespaces unless specified. However, this flag does not exist in Helm 2
HELM_VERSION=$($HELM version --template="{{.Version}}" 2>/dev/null | sed 's/^v\([0-9]*\).*/\1/')
if ! [[ "$HELM_VERSION" =~ ^[0-9]+$ ]]; then
  echo "Unable to determine Helm version, exiting..."
  exit 1
fi
if [ "$HELM_VERSION" -ge 3 ]; then
  HELM_COMMAND="$HELM list --all-namespaces"
else
  echo "Trend Micro Vision One Container Security only supports Helm 3 or newer version, exiting..."
  exit 1
fi


# prepare the output folder
TIME=$(date +%s)
RESULTS_DIR="${RESULTS_DIR:-/tmp/container-security-${TIME}}"
MASTER_DIR="${RESULTS_DIR}/master"
mkdir -p "$MASTER_DIR/apps"
echo "Results folder will be: $RESULTS_DIR"

#####
# setting logs
#####
collect_fimpolicy () {
  $KUBECTL get fimpolicies --all-namespaces -o yaml
  while read -r ns name rest; do
    $KUBECTL get configmap "$name" --namespace "$ns" -o yaml
  done < <($KUBECTL get fimpolicies --all-namespaces --no-headers)
}
COMMANDS=( "version:$KUBECTL version"
           "components:$KUBECTL get componentstatuses"
           "events:$KUBECTL get events --all-namespaces"
           "storageclass:$KUBECTL describe storageclass"
           "helm:$HELM_COMMAND"
           "helm-status:$HELM status $RELEASE $NAMESPACE_PARAM"
           "nodes:$KUBECTL describe nodes"
           "podlist:$KUBECTL get pods --all-namespaces"
           "daemonsets: $KUBECTL get ds --all-namespaces"
           "container-security-get:$KUBECTL get all --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "container-security-desc:$KUBECTL describe all --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "container-security-desc-netpol:$KUBECTL describe networkpolicy --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "container-security-secrets:$KUBECTL get secrets --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "trendmicro-system-all-secrets:$KUBECTL get secrets $NAMESPACE_PARAM"
           "container-security-config:$KUBECTL describe configmap --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "container-security-getvalidatewebhooks:$KUBECTL get ValidatingWebhookConfiguration --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "container-security-descvalidatewebhooks:$KUBECTL describe ValidatingWebhookConfiguration --all-namespaces -l app.kubernetes.io/instance=$RELEASE"
           "workloadimages: $KUBECTL get workloadimages --all-namespaces -o yaml"
           "clusterpolicies: $KUBECTL get clusterpolicies --all-namespaces -o yaml"
           "runtimerulesets: $KUBECTL get runtimerulesets --all-namespaces -o yaml"
           "attestors: $KUBECTL get attestors --all-namespaces -o yaml"
           "cluster: $KUBECTL get clusters.container-security.trendmicro.com --all-namespaces -o yaml"
           "policy-config:$KUBECTL get configmap trendmicro-container-security-policy-config $NAMESPACE_PARAM -o yaml"
           "ruleset-config:$KUBECTL get configmap trendmicro-container-security-runtime-rulesets-config $NAMESPACE_PARAM -o yaml"
           "rules-config:$KUBECTL get configmap trendmicro-container-security-runtime-rules-config $NAMESPACE_PARAM -o yaml"
           "runtime-policy-config:$KUBECTL get configmap trendmicro-container-security-runtime-policy-config $NAMESPACE_PARAM -o yaml"
           "fimpolicy: collect_fimpolicy"
           )

echo "Fetching setting logs..."
for command in "${COMMANDS[@]}"; do
    KEY="${command%%:*}"
    VALUE="${command##*:}"
    echo "Command:" "$VALUE" > "$MASTER_DIR/$KEY.log"
    echo "====================================" >> "$MASTER_DIR/$KEY.log"
    $VALUE >> "$MASTER_DIR/$KEY.log" 2>&1
done

# get values file for current RELEASE and NAMESPACE
VALUES=$($HELM get values $RELEASE -n $NAMESPACE -o yaml)
VALUES=$(echo "$VALUES" | sed 's/apikey: .*/bootstrapToken: xxxxxx/I') # redacting any exposed API keys
VALUES=$(echo "$VALUES" | sed 's/password: .*/password: xxxxxx/I') # redacting any plain-text proxy password
echo "$VALUES" > $MASTER_DIR/$RELEASE-$NAMESPACE-values.yaml

#####
# application logs
#####
for pod in $(echo "$PODS" | tr ";" "\n"); do
    CONTAINERS=$($KUBECTL get pods "$NAMESPACE_PARAM" "$pod" -o jsonpath='{.spec.initContainers[*].name}')
    for container in $CONTAINERS; do
        echo "Fetching container security logs... $pod - $container"
        $KUBECTL logs "$NAMESPACE_PARAM" "$pod" -c "$container" > "$MASTER_DIR/apps/$pod-$container.log"
        # check for any previous containers, this would indicate a crash
        PREV_LOGFILE="$MASTER_DIR/apps/$pod-$container-previous.log"
        if ! $KUBECTL logs "$NAMESPACE_PARAM" "$pod" -c "$container" -p > "$PREV_LOGFILE" 2>/dev/null; then
            rm -f "$PREV_LOGFILE"
        fi
    done

    # list containers in pod
    CONTAINERS=$($KUBECTL get pods "$NAMESPACE_PARAM" "$pod" -o jsonpath='{.spec.containers[*].name}')
    for container in $CONTAINERS; do
        echo "Fetching container security logs... $pod - $container"
        $KUBECTL logs "$NAMESPACE_PARAM" "$pod" -c "$container" > "$MASTER_DIR/apps/$pod-$container.log"
        # check for any previous containers, this would indicate a crash
        PREV_LOGFILE="$MASTER_DIR/apps/$pod-$container-previous.log"
        if ! $KUBECTL logs "$NAMESPACE_PARAM" "$pod" -c "$container" -p > "$PREV_LOGFILE" 2>/dev/null; then
            rm -f "$PREV_LOGFILE"
        fi
    done
done

echo "Results folder: $RESULTS_DIR"
