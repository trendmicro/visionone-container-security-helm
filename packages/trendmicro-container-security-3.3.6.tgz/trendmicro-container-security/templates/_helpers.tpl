{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "container.security.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "container.security.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "container.security.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ include "container.security.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Admission Control Common labels
*/}}
{{- define "admissionController.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "admissionController.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Oversight Common labels
*/}}
{{- define "oversight.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "oversight.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Usage Controller Common labels
*/}}
{{- define "usage.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "usage.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Scan Manager Common labels
*/}}
{{- define "scanManager.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "scanManager.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Scout Common labels
*/}}
{{- define "scout.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "scout.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Workload Operator Common labels
*/}}
{{- define "workloadOperator.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "workloadOperator.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Scanner Common labels
*/}}
{{- define "scanner.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "scanner.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Compliance Scan Job Common labels
*/}}
{{- define "complianceScanJob.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "complianceScanJob.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Fargate Security Common labels
*/}}
{{- define "fargateInjector.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "fargateInjector.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
k8s-metacollector Common labels
*/}}
{{- define "k8sMetaCollector.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "k8sMetaCollector.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
malwareScanner Common labels
*/}}
{{- define "malwareScanner.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "malwareScanner.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Policy Operator Common Labels
*/}}
{{- define "policyOperator.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "policyOperator.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Runtime ruleloader Common Labels
*/}}
{{- define "runtimeRuleloader.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "runtimeRuleloader.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Admission Control Selector labels
*/}}
{{- define "admissionController.selectorLabels" -}}
app.kubernetes.io/name: {{ include "admissionController.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-admission-controller
{{- end }}


{{/*
Oversight Selector labels
*/}}
{{- define "oversight.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oversight.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-oversight
{{- end }}

{{/*
Usage Controller Selector labels
*/}}
{{- define "usage.selectorLabels" -}}
app.kubernetes.io/name: {{ include "usage.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-usage
{{- end }}

{{/*
Scan Manager Selector labels
*/}}
{{- define "scanManager.selectorLabels" -}}
app.kubernetes.io/name: {{ include "scanManager.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-scan-manager
{{- end }}

{{/*
Scout Controller Selector labels
*/}}
{{- define "scout.selectorLabels" -}}
app.kubernetes.io/name: {{ include "scout.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-scout
{{- end }}

{{/*
Workload Operator Selector labels
*/}}
{{- define "workloadOperator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "workloadOperator.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-workload-operator
{{- end }}

{{/*
Scanner Job Selector labels
*/}}
{{- define "scanner.selectorLabels" -}}
app.kubernetes.io/name: {{ include "scanner.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-scanner
{{- end }}

{{/*
Fargate Security Selector labels
*/}}
{{- define "fargateInjector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "fargateInjector.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-fargate-injector
{{- end }}

{{/*
k8s-metacollector Selector labels
*/}}
{{- define "k8sMetaCollector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k8sMetaCollector.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-k8s-metacollector
{{- end }}

{{/*
Policy Operator Selector labels
*/}}
{{- define "policyOperator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "policyOperator.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-policy-operator
{{- end }}

{{/*
Compliance Scan Job Selector labels
*/}}
{{- define "complianceScanJob.selectorLabels" -}}
app.kubernetes.io/name: compliance-scan-job
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-compliance-scan-job
{{- end }}

{{/*
Malware Scanner Selector labels
*/}}
{{- define "malwareScanner.selectorLabels" -}}
app.kubernetes.io/name: {{ include "malwareScanner.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-malware-scanner
{{- end }}

{{/*
Rule Loader Selector labels
*/}}
{{- define "runtimeRuleloader.selectorLabels" -}}
app.kubernetes.io/name: {{ include "runtimeRuleloader.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-runtime-ruleloader
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "container.security.fullname" -}}
{{- if .Values.containerSecurityFullnameOverride -}}
{{- .Values.containerSecurityFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.containerSecurityNameOverride -}}
{{- if contains "trendmicro" $name -}}
{{- printf "%s" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" "trendmicro" $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "admissionController.fullname" -}}
{{- if .Values.admissionControllerFullnameOverride -}}
{{- .Values.admissionControllerFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.admissionContollerNameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "admission-controller" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "admission-controller" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "admission-controller" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "runtimeSecurity.fullname" -}}
{{- if .Values.runtimeSecurityFullnameOverride -}}
{{- .Values.runtimeSecurityFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.runtimeSecurityNameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "runtime-protection" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "runtime-protection" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "runtime-protection" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "oversight.fullname" -}}
{{- if .Values.oversightFullnameOverride -}}
{{- .Values.oversightFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.oversightFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "oversight" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "oversight" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "oversight" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "usage.fullname" -}}
{{- if .Values.usageFullnameOverride -}}
{{- .Values.usageFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.usageFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "usage" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "usage" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "usage" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "scanManager.fullname" -}}
{{- if .Values.scanManagerFullnameOverride -}}
{{- .Values.scanManagerFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.scanManagerFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "scan-manager" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "scan-manager" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "scan-manager" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "scout.fullname" -}}
{{- if .Values.scoutFullnameOverride -}}
{{- .Values.scoutFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.scoutFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "scout" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "scout" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "scout" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "workloadOperator.fullname" -}}
{{- if .Values.workloadOperatorFullnameOverride -}}
{{- .Values.workloadOperatorFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.workloadOperatorFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "workload-operator" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "workload-operator" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "workload-operator" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "scanner.fullname" -}}
{{- if .Values.scannerFullnameOverride -}}
{{- .Values.scannerFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.scannerFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "scanner" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "scanner" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "scanner" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "complianceScanner.fullname" -}}
{{- if .Values.complianceScannerFullnameOverride -}}
{{- .Values.complianceScannerFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.complianceScannerFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "compliance-scanner" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "compliance-scanner" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "compliance-scanner" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "fargateInjector.fullname" -}}
{{- if .Values.fargateInjectorFullnameOverride -}}
{{- .Values.fargateInjectorFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.fargateInjectorNameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "fargate-injector" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "fargate-injector" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "fargate-injector" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "k8sMetaCollector.fullname" -}}
{{- if .Values.k8sMetacollectorFullnameOverride -}}
{{- .Values.k8sMetacollectorFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.k8sMetacollectorFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "k8s-metacollector" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "k8s-metacollector" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "k8s-metacollector" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "policyOperator.fullname" -}}
{{- if .Values.policyOperatorFullnameOverride -}}
{{- .Values.policyOperatorFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.policyOperatorFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "policy-operator" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "policy-operator" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "policy-operator" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "malwareScanner.fullname" -}}
{{- if .Values.malwareScannerFullnameOverride -}}
{{- .Values.malwareScannerFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.malwareScannerFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "malware-scanner" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "malware-scanner" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "malware-scanner" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "runtimeRuleloader.fullname" -}}
{{- if .Values.runtimeRuleloaderFullnameOverride -}}
{{- .Values.runtimeRuleloaderFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.runtimeRuleloaderFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "runtime-ruleloader" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "runtime-ruleloader" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "runtime-ruleloader" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Service name of k8s-metacollector
*/}}
{{- define "k8sMetaCollector.svc.url" -}}
{{- printf "%s.%s.svc.cluster.local:45000" (include "k8sMetaCollector.fullname" .) .Release.Namespace -}}
{{- end -}}
{{/*
Service name of k8s-metacollector without port, used to generate certificate name
*/}}
{{- define "k8sMetaCollector.svc.urlnoport" -}}
{{- printf "%s.%s.svc.cluster.local" (include "k8sMetaCollector.fullname" .) .Release.Namespace -}}
{{- end -}}

{{/*
Service name of malware scanner
*/}}
{{- define "malwareScanner.svc" -}}
{{- printf "trendmicro-malware-scanner" -}}
{{- end -}}

{{/*
Service url of malware scanner
*/}}
{{- define "malwareScanner.svc.url" -}}
{{- printf "%s.%s.svc.cluster.local" (include "malwareScanner.svc" .) .Release.Namespace -}}
{{- end -}}


{{/*
Service name of secret scanner
*/}}
{{- define "secretScanner.svc" -}}
{{- printf "trendmicro-secret-scanner" -}}
{{- end -}}

{{/*
Service url of secret scanner
*/}}
{{- define "secretScanner.svc.url" -}}
{{- printf "%s.%s.svc.cluster.local" (include "secretScanner.svc" .) .Release.Namespace -}}
{{- end -}}

{{/*
Create an image source.
*/}}
{{- define "image.source" -}}
{{- if and (not .registry) (not .imageDefaults.registry) -}}
{{- if .digest -}}
{{- printf "%s@%s" .repository .digest | quote -}}
{{- else -}}
{{- printf "%s:%s" .repository .tag | quote -}}
{{- end -}}
{{- else -}}
{{- if .digest -}}
{{- printf "%s/%s@%s" (default .imageDefaults.registry .registry) .repository .digest | quote -}}
{{- else -}}
{{- printf "%s/%s:%s" (default .imageDefaults.registry .registry) .repository .tag | quote -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Vision One bootstrap token
*/}}
{{- define "container.security.auth.secret" -}}
{{- if hasKey .Values.visionOne "apiKey" }}
{{- fail "apiKey key is renamed bootstrapToken. See docs/upgrade-from-cloud-one-helm.md" }}
{{- end }}
{{- if and .Values.visionOne.bootstrapToken (not (hasPrefix "ey" .Values.visionOne.bootstrapToken))}} # bootstrap token is a JWT token
{{- fail "Invalid bootstrapToken format." }}
{{- end }}
{{- if not .Values.visionOne.clusterRegistrationKey }}
{{- if not (and .Values.useExistingSecrets (eq true .Values.useExistingSecrets.containerSecurityAuth)) }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ template "container.security.fullname" . }}-bootstrap-token
  labels:
    {{- include "container.security.labels" . | nindent 4 }}
type: Opaque
data:
{{- if and (hasKey .Values.visionOne "bootstrapToken") (.Values.visionOne.bootstrapToken) }}
  bootstrap.token: {{ .Values.visionOne.bootstrapToken | toString | b64enc | quote }}
{{- else }}
  bootstrap.token: {{ required "A valid Vision One bootstrapToken is required" .Values.visionOne.bootstrapToken | toString | b64enc | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}{{/* define */}}

{{/*
Vision One API endpoint
*/}}
{{- define "container.security.endpoint" -}}
{{- if and (hasKey .Values.visionOne "endpoint") (.Values.visionOne.endpoint) }}
{{- .Values.visionOne.endpoint -}}
{{- else }}
{{- required "A valid Vision One endpoint is required" .Values.visionOne.endpoint -}}
{{- end }}
{{- end -}}{{/* define */}}

{{/*
Provide HTTP proxy environment variables
*/}}
{{- define "container.security.proxy.env" -}}
- name: _PROXY_CONFIG_CHECKSUM
  value: {{ include (print $.Template.BasePath "/outbound-proxy.yaml") . | sha256sum }}
- name: HTTP_PROXY
  valueFrom:
    configMapKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy
      key: httpProxy
- name: HTTPS_PROXY
  valueFrom:
    configMapKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy
      key: httpsProxy
- name: ALL_PROXY
  valueFrom:
    secretKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy-credentials
      key: allProxy
- name: NO_PROXY
  valueFrom:
    configMapKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy
      key: noProxy
- name: PROXY_USER
  valueFrom:
    secretKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy-credentials
      key: username
- name: PROXY_PASS
  valueFrom:
    secretKeyRef:
      name: {{ template "container.security.name" . }}-outbound-proxy-credentials
      key: password
{{- end -}}{{/*define*/}}

{{/*
TLS configuration - TLS min version
*/}}
{{- define "tlsConfig.minTLSVersion" -}}
{{- if .minTLSVersion }}
{{- .minTLSVersion }}
{{- else }}
{{- "VersionTLS12" }}
{{- end }}
{{- end }}

{{/*
TLS configuration - TLS cipher suites
*/}}
{{- define "tlsConfig.cipherSuites" -}}
{{- if .cipherSuites }}
{{- join "," .cipherSuites }}
{{- else }}
{{- "" }}
{{- end }}
{{- end }}

{{/*
Admission Controller Service Account
*/}}
{{- define "admissionController.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "admissionController.fullname" .) .Values.serviceAccount.admissionController.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.admissionController.name }}
{{- end }}
{{- end }}

{{/*
Oversight service account
*/}}
{{- define "oversight.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "oversight.fullname" .) .Values.serviceAccount.oversight.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.oversight.name }}
{{- end }}
{{- end }}

{{/*
Usage Controller service account
*/}}
{{- define "usage.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "usage.fullname" .) .Values.serviceAccount.usage.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.usage.name }}
{{- end }}
{{- end }}

{{/*
Scout Controller service account
*/}}
{{- define "scout.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "scout.fullname" .) .Values.serviceAccount.scout.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.scout.name }}
{{- end }}
{{- end }}

{{/*
Scan Manager service account
*/}}
{{- define "scanManager.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "scanManager.fullname" .) .Values.serviceAccount.scanManager.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.scanManager.name }}
{{- end }}
{{- end }}

{{/*
Scan Job service account
*/}}
{{- define "scanJob.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "scanner.fullname" .) .Values.serviceAccount.scanJob.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.scanJob.name }}
{{- end }}
{{- end }}

{{/*
Compliance Scan Job service account
*/}}
{{- define "complianceScanJob.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "complianceScanner.fullname" .) .Values.serviceAccount.complianceScanJob.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.complianceScanJob.name }}
{{- end }}
{{- end }}

{{/*
Workload Operator service account
*/}}
{{- define "workloadOperator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "workloadOperator.fullname" .) .Values.serviceAccount.workloadOperator.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.workloadOperator.name }}
{{- end }}
{{- end }}

{{/*
Fargate Injector service account
*/}}
{{- define "fargateInjector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "fargateInjector.fullname" .) .Values.serviceAccount.fargateInjector.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.fargateInjector.name }}
{{- end }}
{{- end }}

{{/*
k8s-collector service account
*/}}
{{- define "k8sMetaCollector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "k8sMetaCollector.fullname" .) .Values.serviceAccount.k8sMetaCollector.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.k8sMetaCollector.name }}
{{- end }}
{{- end }}

{{/*
Malware Scanner service account
*/}}
{{- define "malwareScanner.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "malwareScanner.fullname" .) .Values.serviceAccount.malwareScanner.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.malwareScanner.name }}
{{- end }}
{{- end }}

{{/*
Policy Operator service account
*/}}
{{- define "policyOperator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "policyOperator.fullname" .) .Values.serviceAccount.policyOperator.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.policyOperator.name }}
{{- end }}
{{- end }}

{{/*
Runtime ruleloader service account
*/}}
{{- define "runtimeRuleloader.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "runtimeRuleloader.fullname" .) .Values.serviceAccount.runtimeRuleloader.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.runtimeRuleloader.name }}
{{- end }}
{{- end }}

{{/*
Return the target Kubernetes version
*/}}
{{- define "kubeVersion" -}}
{{- $version := semver .Capabilities.KubeVersion.Version }}
{{- printf "%v.%v.%v" $version.Major $version.Minor $version.Patch -}}
{{- end -}}

{{/*
Return the logLevel for the component
*/}}
{{- define "logLevel" -}}
{{- $componentLogLevel := index . 0 }}
{{- $ctx := index . 1 }}
{{- if $ctx.Values.logConfig.logLevel }}
{{- $ctx.Values.logConfig.logLevel }}
{{- else if $componentLogLevel }}
{{- $componentLogLevel }}
{{- else }}
{{- "info" }}
{{- end }}
{{- end -}}

{{/*
Return the trusted images digest
*/}}
{{- define "digest" -}}
{{- $digest :=""}}
{{- range $image := .Values.images }}
{{- if $image.digest}}
{{- if $digest}}
{{- $digest = printf "%s,%s" $digest $image.digest}}
{{- else}}
{{- $digest = $image.digest}}
{{- end }}
{{- end }}
{{- end }}
{{- $digest}}
{{- end -}}

{{/*
Validate input from override file
*/}}
{{- define "validateClusterInput" -}}
{{- if hasKey .Values "cloudOne" }}
{{- fail "cloudOne key is renamed visionOne. See docs/upgrade-from-cloud-one-helm.md" }}
{{- end }}
{{- if and (hasKey .Values.visionOne "endpoint") (hasPrefix "https://container." .Values.visionOne.endpoint)}}
{{- fail "Cannot use Cloud One endpoint. See docs/upgrade-from-cloud-one-helm.md" }}
{{- end }}
{{- if and .Values.visionOne.bootstrapToken .Values.visionOne.clusterRegistrationKey }}
{{- fail "Please do not specify the bootstrapToken in the override file when using automated cluster registration" }}
{{- end }}
{{- if and (not .Values.visionOne.groupId ) (.Values.visionOne.clusterRegistrationKey) }}
{{- fail "Please specify the groupId in the override file when using automated cluster registration" }}
{{- end }}
{{- if and .Values.visionOne.clusterName (gt (float64 (len .Values.visionOne.clusterName)) 64.0) }}
{{- fail "The cluster name must be less than 64 characters" }}
{{- end }}
{{- if and .Values.visionOne.clusterName (not (regexMatch "^[a-zA-Z0-9._]+$" .Values.visionOne.clusterName)) }}
{{- fail "The cluster name must only contain alphanumeric characters, dots, and underscores" }}
{{- end }}
{{- if and .Values.visionOne.clusterNamePrefix (gt (float64 (len .Values.visionOne.clusterNamePrefix)) 16.0) }}
{{- fail "The cluster name prefix must be less than 16 characters" }}
{{- end }}
{{- if and .Values.visionOne.clusterNamePrefix (not (regexMatch "^[a-zA-Z0-9._]+$" .Values.visionOne.clusterNamePrefix)) }}
{{- fail "The cluster name prefix must only contain alphanumeric characters, dots, and underscores" }}
{{- end }}
{{- if and (not .Values.visionOne.groupId ) (.Values.visionOne.clusterRegistrationKey) }}
{{- fail "Please specify the groupId in the override file when using automated cluster registration" }}
{{- end }}
{{- end -}}

{{- define "falco.securityContext" -}}
{{- $falcosecurityContext := default .Values.securityContext.default.container .Values.securityContext.scout.falco -}}
{{- if .Values.scout.falco.least_privileged }}
  {{- $patch := dict -}}
  {{- $patch := set $patch "privileged" false -}}
  {{- $patch := set $patch "capabilities" (dict "add" (list "SYS_ADMIN" "SYS_RESOURCE" "SYS_PTRACE")) -}}
  {{- $falcosecurityContext := mergeOverwrite $falcosecurityContext $patch -}}
{{- end -}}
{{- toYaml $falcosecurityContext }}
{{- end -}}


{{/*
Return the arguments for container runtime's sockets
Usage:
{{ include "containerRuntime.sock.args" ( list "cri-arg-name" "path-prefix" .Values.scout.falco ) }}
*/}}
{{- define "containerRuntime.sock.args"  -}}
{{- $arg := index . 0 -}}
{{- $pathprefix := index . 1 -}}
{{- $context := index . 2 -}}
{{- if and $context.docker $context.docker.enabled }}
- --{{$arg}}
- {{$pathprefix}}/var/run/docker.sock
{{- end }}{{/* if */}}
{{- if and $context.cri $context.cri.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/cri/cri.sock
{{- end }}{{/* if */}}
{{- if and $context.dockershim $context.dockershim.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/dockershim.sock
{{- end }}{{/* if */}}
{{- if and $context.k0s $context.k0s.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/k0s/containerd.sock
{{- end }}{{/* if */}}
{{- if and $context.k3s $context.k3s.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/k3s/containerd/containerd.sock
{{- end }}{{/* if */}}
{{- if and $context.containerd $context.containerd.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/containerd/containerd.sock
{{- end }}{{/* if */}}
{{- if and $context.crio $context.crio.enabled }}
- --{{$arg}}
- {{$pathprefix}}/run/crio/crio.sock
{{- end }}{{/* if */}}
{{- end -}}

{{/*
Return the Falco arguments for container runtime's sockets
Usage:
{{ include "containerRuntime.sock.falco.args" .Values.scout.falco }}
*/}}
{{- define "containerRuntime.sock.falco.args" -}}
{{- if and .docker .docker.enabled }}
- -o
- container_engines.cri.sockets[]=/var/run/docker.sock
{{- end }}{{/* if */}}
{{- if and .cri .cri.enabled }}
- -o
- container_engines.cri.sockets[]=/run/cri/cri.sock
{{- end }}{{/* if */}}
{{- if and .dockershim .dockershim.enabled }}
- -o
- container_engines.cri.sockets[]=/run/dockershim.sock
{{- end }}{{/* if */}}
{{- if and .k0s .k0s.enabled }}
- -o
- container_engines.cri.sockets[]=/run/k0s/containerd.sock
{{- end }}{{/* if */}}
{{- if and .k3s .k3s.enabled }}
- -o
- container_engines.cri.sockets[]=/run/k3s/containerd/containerd.sock
{{- end }}{{/* if */}}
{{- if and .containerd .containerd.enabled }}
- -o
- container_engines.containerd.sockets[]=/run/containerd/containerd.sock
{{- end }}{{/* if */}}
{{- if and .crio .crio.enabled }}
- -o
- container_engines.crio.sockets[]=/run/crio/crio.sock
{{- end }}{{/* if */}}
{{- end -}}

{{/*
Return the volume mounts for container runtime's sockets
Usage:
{{ include "containerRuntime.sock.volumeMounts" ( list "path-prefix" .Values.scout.falco ) }}
*/}}
{{- define "containerRuntime.sock.volumeMounts" -}}
{{- $pathprefix := index . 0 -}}
{{- $context := index . 1 -}}
{{- if and $context.docker $context.docker.enabled }}
- mountPath: {{$pathprefix}}/var/run/docker.sock
  name: docker-socket
{{- end}}{{/* if */}}
{{- if and $context.cri.enabled $context.cri.socket}}
- mountPath: {{$pathprefix}}/run/cri/cri.sock
  name: cri-socket
{{- end}}{{/* if */}}
{{- if and $context.dockershim $context.dockershim.enabled }}
- mountPath: {{$pathprefix}}/run/dockershim.sock
  name: dockershim-socket
{{- end}}{{/* if */}}
{{- if and $context.k0s $context.k0s.enabled }}
- mountPath: {{$pathprefix}}/run/k0s/containerd.sock
  name: k0s-socket
{{- end}}{{/* if */}}
{{- if and $context.k3s $context.k3s.enabled }}
- mountPath: {{$pathprefix}}/run/k3s/containerd/containerd.sock
  name: k3s-socket
{{- end}}{{/* if */}}
{{- if and $context.containerd $context.containerd.enabled }}
- mountPath: {{$pathprefix}}/run/containerd/containerd.sock
  name: containerd-socket
{{- end}}{{/* if */}}
{{- if and $context.crio $context.crio.enabled }}
- mountPath: {{$pathprefix}}/run/crio/crio.sock
  name: crio-socket
{{- end}}{{/* if */}}
{{- end -}}

{{/*
Return the volume for container runtime's sockets
Usage:
{{ include "containerRuntime.sock.volumes" ( list $ .Values.scout.falco ) }}
*/}}
{{- define "containerRuntime.sock.volumes"  -}}
{{- $ := index . 0 -}}
{{- $context := index . 1 -}}
{{- if $context.docker.enabled }}
- name: docker-socket
  hostPath:
    path: {{ $context.docker.socket }}
{{- end}}{{/* if */}}
{{- if and $context.cri.enabled $context.cri.socket}}
- name: cri-socket
  hostPath:
    path: {{ $context.cri.socket }}
{{- end }}{{/* if */}}
{{- if (and $context.dockershim $context.dockershim.enabled) }}
- name: dockershim-socket
  hostPath:
    # default is /run/dockershim.sock on bottlerocket.
    {{- $defaultdockershimpath := "/run/dockershim.sock" }}
    path: {{ $context.dockershim.socket | default $defaultdockershimpath }}
{{- end }}{{/* if */}}
{{- if (and $context.k0s $context.k0s.enabled) }}
- name: k0s-socket
  hostPath:
    {{- $defaultk0spath := "/run/k0s/containerd.sock" }}
    path: {{ $context.k0s.socket | default $defaultk0spath }}
{{- end }}{{/* if */}}
{{- if (and $context.k3s $context.k3s.enabled) }}
- name: k3s-socket
  hostPath:
    {{- $defaultk3spath := "/run/k3s/containerd/containerd.sock" }}
    path: {{ $context.k3s.socket | default $defaultk3spath }}
{{- end }}{{/* if */}}
{{- if (and $context.containerd $context.containerd.enabled) }}
- name: containerd-socket
  hostPath:
    {{- $defaultcontainerdspath := "/run/containerd/containerd.sock " }}
    path: {{ $context.containerd.socket | default $defaultcontainerdspath }}
{{- end }}{{/* if */}}
{{- if (and $context.crio $context.crio.enabled) }}
- name: crio-socket
  hostPath:
    {{- $defaultcriospath := "/run/crio/crio.sock" }}
    path: {{ $context.crio.socket | default $defaultcriospath}}
{{- end }}{{/* if */}}
{{- end -}}

{{/*
Automatically adds any namespace with prefix to excluded namespace list for openshift
*/}}
{{- define "namespaceExclusions" -}}
{{- $excludedNamespaces := .Values.visionOne.exclusion.namespaces | default list -}}
{{- $osNsPrefixes := .Values.visionOne.exclusion.osNsPrefixes | default list -}}

{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1" -}}
  {{- $namespaceList := lookup "v1" "Namespace" "" "" -}}
  {{- if $namespaceList -}}
    {{- range $index, $namespace := $namespaceList.items -}}
      {{- range $prefix := $osNsPrefixes -}}
        {{- if hasPrefix $prefix $namespace.metadata.name -}}
          {{- $excludedNamespaces = append $excludedNamespaces $namespace.metadata.name -}}
          {{- break -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- join "," $excludedNamespaces -}}
{{- end -}}

{{/*
   Determines whether Scout should be deployed based on enabled Vision One features.
   This helper centralizes the deployment condition to avoid duplication in multiple templates.
   It returns "true" (as a string) if any of the following features are enabled:
   - Runtime Security
   - Malware Scanning
   - Secret Scanning
   - File Integrity Monitoring
   Otherwise, it returns "false".
   Usage:
   {{- if eq (include "scout.shouldDeploy" .) "true" }}
*/}}
{{- define "scout.shouldDeploy" -}}
{{- if and (or (eq true .Values.visionOne.runtimeSecurity.enabled) (eq true .Values.visionOne.malwareScanning.enabled) (eq true .Values.visionOne.secretScanning.enabled) (eq true .Values.visionOne.fileIntegrityMonitoring.enabled)) (eq (include "container.security.skipStandardComponents" .) "false") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
   Determines whether k8s-metacollector should be deployed based on enabled Vision One features.
   This helper centralizes the deployment condition to avoid duplication in multiple templates.
   It returns "true" (as a string) if any of the following features are enabled:
   - Runtime Security
   - Malware Scanning
   - Secret Scanning
   - File Integrity Monitoring
   Otherwise, it returns "false".
   Usage:
   {{- if eq (include "metacollector.shouldDeploy" .) "true" }}
*/}}
{{- define "metacollector.shouldDeploy" -}}
{{- if and (or (eq true .Values.visionOne.runtimeSecurity.enabled) (eq true .Values.visionOne.malwareScanning.enabled) (eq true .Values.visionOne.secretScanning.enabled) (eq true .Values.visionOne.fileIntegrityMonitoring.enabled)) (eq (include "container.security.skipStandardComponents" .) "false") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Return the sanitizer output configuration
*/}}
{{- define "falco.sanitier.ouput" -}}
{{- if .Values.scout.falco.sanitizer_output.enabled }}
{{- if .Values.scout.falco.sanitizer_output.patterns }}
sanitizer_output:
  enabled: true
  patterns:
    {{- range $key, $value := .Values.scout.falco.sanitizer_output.patterns }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
{{- else }}
{{- fail "Redaction pattern is required if output sanitizer is enabled." }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Return the url of the policy operator service
*/}}
{{- define "policyOperator.svc.url" -}}
{{- printf "http://trendmicro-policy-operator-service.%s.svc.cluster.local:%d/api" .Release.Namespace (int .Values.visionOne.policyOperator.servicePort) }}
{{- end -}}

{{/*
Return the volumes for self-signed certificates
*/}}
{{- define "proxy.selfSignedCertificates.volumes" }}
{{- range .Values.proxy.selfSignedCertificates}}
- name: {{ .name }}
{{- if eq .type "secret" }}
  secret:
    secretName: {{ .secretName | quote }}
{{- else if eq .type "configMap" }}
  configMap:
    name: {{ .configMapName | quote }}
{{- else if eq .type "hostPath" }}
  hostPath:
    path: {{ .path | quote }}
    type: File
{{- end }}
{{- end }}
{{- end }}

{{/*
Return the volume mounts for self-signed certificates
*/}}
{{- define "proxy.selfSignedCertificates.volumeMounts" }}
{{- range .Values.proxy.selfSignedCertificates}}
- name: {{ .name }}
  mountPath: /etc/self-signed-certs/certificate.crt
{{- if and (eq .type "secret") .key }}
  subPath: {{ .key }}
{{- else if and (eq .type "configMap") .key }}
  subPath: {{ .key }}
{{- end }}
  readOnly: true
{{- end }}
{{- end }}


{{/*
Return the SSL_CERT_FILE env for self-signed certificates
*/}}
{{- define "proxy.selfSignedCertificates.env" }}
{{- if .Values.proxy.selfSignedCertificates }}
- name: SSL_CERT_FILE
  value: /etc/self-signed-certs/certificate.crt
{{- end }}
{{- end }}

{{/*
Audit Log Collector Common labels
*/}}
{{- define "auditLogCollector.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "auditLogCollector.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Audit Log Collector Selector labels
*/}}
{{- define "auditLogCollector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "auditLogCollector.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-audit-log-collector
{{- end }}

{{/*
API Server Modifier Common labels
*/}}
{{- define "apiServerModifier.labels" -}}
helm.sh/chart: {{ include "container.security.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "container.security.name" . }}
{{ include "apiServerModifier.selectorLabels" . }}
{{- range $k, $v := (default (dict) .Values.extraLabels) }}
{{ $k }}: {{ quote $v }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
API Server Modifier Selector labels
*/}}
{{- define "apiServerModifier.selectorLabels" -}}
app.kubernetes.io/name: {{ include "apiServerModifier.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: trendmicro-api-server-modifier
{{- end }}

{{/*
Create a default fully qualified app name for Audit Log Collector.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "auditLogCollector.fullname" -}}
{{- if .Values.auditLogCollectorFullnameOverride -}}
{{- .Values.auditLogCollectorFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.auditLogCollectorFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "audit-log-collector" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "audit-log-collector" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "audit-log-collector" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name for API Server Modifier.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "apiServerModifier.fullname" -}}
{{- if .Values.apiServerModifierFullnameOverride -}}
{{- .Values.apiServerModifierFullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.apiServerModifierFullnameOverride -}}
{{- if contains $name .Release.Name -}}
{{- printf "%s-%s" "api-server-modifier" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Release.Name $name -}}
{{- printf "%s-%s" "api-server-modifier" $name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" "api-server-modifier" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Audit Log Collector service account
*/}}
{{- define "auditLogCollector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "auditLogCollector.fullname" .) .Values.serviceAccount.auditLogCollector.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.auditLogCollector.name }}
{{- end }}
{{- end }}

{{/*
API Server Modifier service account
*/}}
{{- define "apiServerModifier.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "apiServerModifier.fullname" .) .Values.serviceAccount.apiServerModifier.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.apiServerModifier.name }}
{{- end }}
{{- end }}

{{/*
Check if we're in gardener seed cluster mode
*/}}
{{- define "container.security.gardener.seedCluster" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "gardener") .Values.auditLogCollection.gardener.seedCluster -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Check if we should deploy seed cluster components (audit-log-collector, api-server-modifier, policy-operator)
*/}}
{{- define "container.security.deployOnSeedCluster" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "gardener") .Values.auditLogCollection.gardener.seedCluster -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Check if we should NOT deploy standard V1CS components (when in seed cluster mode)
*/}}
{{- define "container.security.skipStandardComponents" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "gardener") .Values.auditLogCollection.gardener.seedCluster -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Return helm.sh/resource-policy: keep annotation only in seed cluster mode.
This prevents CRDs from being deleted when uninstalling the chart in seed cluster mode,
allowing multiple installations to share the same CRDs.
In non-seed cluster mode, CRDs are removed on uninstall (normal behavior).
Usage: {{ include "container.security.crdResourcePolicy" . | nindent 4 }}
*/}}
{{- define "container.security.crdResourcePolicy" -}}
{{- if eq (include "container.security.gardener.seedCluster" .) "true" -}}
helm.sh/resource-policy: keep
{{- end -}}
{{- end -}}

{{/*
Generate cluster resource name with namespace suffix for seed cluster mode
In seed cluster mode, cluster-scoped resources (ClusterRole, ClusterRoleBinding) need
unique names per namespace to allow multiple installations in different namespaces.
Usage: {{ include "container.security.clusterResourceName" (dict "name" "my-cluster-role" "context" .) }}
*/}}
{{- define "container.security.clusterResourceName" -}}
{{- $name := .name -}}
{{- $ctx := .context -}}
{{- if eq (include "container.security.gardener.seedCluster" $ctx) "true" -}}
{{- printf "%s-%s" $name $ctx.Release.Namespace -}}
{{- else -}}
{{- $name -}}
{{- end -}}
{{- end -}}

{{/*
Generate Cluster CR name - namespace-suffixed in seed cluster mode for multi-install support
*/}}
{{- define "container.security.clusterCRName" -}}
{{- if eq (include "container.security.gardener.seedCluster" .) "true" -}}
trendmicro-cluster-{{ .Release.Namespace }}
{{- else -}}
trendmicro-cluster
{{- end -}}
{{- end -}}

{{/*
Check if custom rules are enabled (either via OCI repository or configmap)
Returns "true" if custom rules should be enabled, empty string otherwise
*/}}
{{- define "customRules.enabled" -}}
{{- if or .Values.visionOne.runtimeSecurity.customRules.ociRepository.enabled .Values.visionOne.runtimeSecurity.customRules.configmap.name -}}
true
{{- end -}}
{{- end -}}

{{/*
Check if we should deploy for selfManaged provider
Returns "true" if selfManaged provider is enabled, empty string otherwise
*/}}
{{- define "container.security.deployForSelfManaged" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "selfManaged") -}}
true
{{- end -}}
{{- end -}}

{{/*
Check if we should deploy audit log collection components (for any supported provider)
Returns "true" if audit log components should be deployed, empty string otherwise
*/}}
{{- define "container.security.deployAuditLogComponents" -}}
{{- if or (eq (include "container.security.deployOnSeedCluster" .) "true") (eq (include "container.security.deployForSelfManaged" .) "true") (eq (include "container.security.deployForCloudProvider" .) "true") -}}
true
{{- end -}}
{{- end -}}

{{/*
Validate auditLogCollection.provider is a supported value
Fails with descriptive error for invalid values
*/}}
{{- define "container.security.validateProvider" -}}
{{- if .Values.auditLogCollection.enabled -}}
{{- $validProviders := list "gardener" "selfManaged" "eks" "aks" "gke" -}}
{{- if not (has .Values.auditLogCollection.provider $validProviders) -}}
{{- fail (printf "Invalid auditLogCollection.provider: %s. Must be one of: %s" .Values.auditLogCollection.provider (join ", " $validProviders)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Check if we should deploy for cloud providers (eks, aks, gke)
Returns "true" if a cloud provider is enabled, empty string otherwise
*/}}
{{- define "container.security.deployForCloudProvider" -}}
{{- if and .Values.auditLogCollection.enabled (has .Values.auditLogCollection.provider (list "eks" "aks" "gke")) -}}
true
{{- end -}}
{{- end -}}

{{/*
Validate EKS provider configuration
Fails if required fields are not set
*/}}
{{- define "container.security.validateEksConfig" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "eks") -}}
{{- if not .Values.auditLogCollection.eks.region -}}
{{- fail "auditLogCollection.eks.region is required when provider is 'eks'" -}}
{{- end -}}
{{- if not .Values.auditLogCollection.eks.clusterName -}}
{{- fail "auditLogCollection.eks.clusterName is required when provider is 'eks'" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Validate AKS provider configuration
Fails if required fields are not set
*/}}
{{- define "container.security.validateAksConfig" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "aks") -}}
{{- if not .Values.auditLogCollection.aks.eventHubConnectionString -}}
{{- fail "auditLogCollection.aks.eventHubConnectionString is required when provider is 'aks'" -}}
{{- end -}}
{{- if not .Values.auditLogCollection.aks.eventHubName -}}
{{- fail "auditLogCollection.aks.eventHubName is required when provider is 'aks'" -}}
{{- end -}}
{{- if not .Values.auditLogCollection.aks.blobStorageConnectionString -}}
{{- fail "auditLogCollection.aks.blobStorageConnectionString is required when provider is 'aks'" -}}
{{- end -}}
{{- if not .Values.auditLogCollection.aks.blobStorageContainerName -}}
{{- fail "auditLogCollection.aks.blobStorageContainerName is required when provider is 'aks'" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Validate GKE provider configuration
Fails if required fields are not set
*/}}
{{- define "container.security.validateGkeConfig" -}}
{{- if and .Values.auditLogCollection.enabled (eq .Values.auditLogCollection.provider "gke") -}}
{{- if not .Values.auditLogCollection.gke.gcpProjectId -}}
{{- fail "auditLogCollection.gke.gcpProjectId is required when provider is 'gke'" -}}
{{- end -}}
{{- if not .Values.auditLogCollection.gke.pubSubSubscription -}}
{{- fail "auditLogCollection.gke.pubSubSubscription is required when provider is 'gke'" -}}
{{- end -}}
{{- end -}}
{{- end -}}
